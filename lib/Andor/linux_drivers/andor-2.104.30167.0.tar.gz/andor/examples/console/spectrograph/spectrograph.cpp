/*Andor example program showing the use of the SDK to
perform a single full vertical binned acquisition from
the CCD*/
#include <stdio.h>

#include <iostream>
#include <fstream>
using namespace std;

#if defined(__linux__)  || defined(__APPLE__)
#include <stdlib.h>
#include <unistd.h>
#include "atmcdLXd.h"

char initDir[] = { "/usr/local/etc/andor" };
#define SLEEP(x) sleep(x)
#else
#include <Windows.h>
#include "ATMCD32D.h"
char initDir[] = { "" };
#define SLEEP(x) Sleep(x * 1000)
#endif

#include "atspectrograph.h"


int CameraSelect (int iNumArgs, char* szArgList[]);
void DisplaySpectrographStatus();

int main(int argc, char* argv[])
{
    if (CameraSelect (argc, argv) < 0) {
        cout << "*** CAMERA SELECTION ERROR" << endl;
		return -1;
    }

	eATSpectrographReturnCodes specrographError;
    unsigned int sdkError;
	bool quit;
	char choice;
	float fChoice;
	int width, height;

	//Initialize CCD
	sdkError = Initialize(initDir);
	if(sdkError!=DRV_SUCCESS){
	  cout << "Initialisation error...exiting" <<endl;
		return(1);
	}
	//Initialize ATSpectrograph CCD
	specrographError = ATSpectrographInitialize(initDir);
	if(specrographError!=ATSPECTROGRAPH_SUCCESS){
		cout << "ATSpectrograph Initialisation error...exiting" <<endl;
		ShutDown();
		return(1);
	}
	int nodevices(0);
	ATSpectrographGetNumberDevices(&nodevices);
	if(nodevices < 1) {
		cout << "No Spectrograph detected...exiting" <<endl;
		ATSpectrographClose();
		ShutDown();
		return(1);
	}

	//Set Read Mode to --Full Vertical Binning--
	SetReadMode(0);

	//Set Acquisition mode to --Single scan--
	SetAcquisitionMode(1);

	//Set initial exposure time
	SetExposureTime(0.1f);

	//Get Detector dimensions
	GetDetector(&width, &height);

	//Sets the number of pixels for calibration purposes
	ATSpectrographSetNumberPixels(0, width);

	float xSize, ySize;
	//Get Detector pixel size
	GetPixelSize(&xSize, &ySize);

	//Set the pixel width in microns for calibration purposes.
	ATSpectrographSetPixelWidth(0, xSize);

	//Initialize Shutter
	SetShutter(1,0,50,50);

	quit = false;
	do{
		//Show menu options
		cout << "        Menu" << endl;
		cout << "===================="   << endl;
		DisplaySpectrographStatus();
		cout << "a. Start Acquisition"   << endl;
		cout << "b. Set Exposure Time"   << endl;
		cout << "c. Set Grating"         << endl;
		cout << "d. Set Wavelength"      << endl;
		cout << "e. Display Calibration" << endl;
		cout << "z.     Exit"            << endl;
		cout << "===================="   << endl;
		cout << "Choice?::";
		//Get menu choice
		choice = getchar();

		switch(choice){
		case 'a': //Acquire
			{
			StartAcquisition();

			int status;
			unsigned short *  counts = new unsigned short[width];
			float *  waves = new float[width];

			fstream fout("spectrum.asc", ios::out);

			//Loop until acquisition finished
			GetStatus(&status);
			while(status==DRV_ACQUIRING) GetStatus(&status);

			GetAcquiredData16(counts, width);
			ATSpectrographGetCalibration(0, waves, width);

			for(int i=0;i<width;i++) fout << waves[i] << "\t" << counts[i] << endl;

     		delete [] counts;
			delete [] waves;
                        }
			break;

		case 'b': //Set new exposure time

			cout << endl << "Enter new Exposure Time(s)::";
			cin >> fChoice;

			SetExposureTime(fChoice);

			break;
		case 'c': //Set grating
			cout << "     Grating Menu\n";
			cout << "====================" << endl;
		{
			int noGratings(0);
			int iChoice(0);
			ATSpectrographGetNumberGratings(0, &noGratings);
			float Lines(0.0f);
			float Min, Max;
			char Blaze[32];
			int Home, Offset;
			for(int i = 1; i <= noGratings;++i) {
				ATSpectrographGetGratingInfo(0, i, &Lines, Blaze, 31, &Home, &Offset);
				ATSpectrographGetWavelengthLimits(0, i, &Min, &Max);
				cout << "\t" << i
				     << ". Lines:" << Lines
					 << "/mm; Blaze: " << Blaze
					 << "nm; Limits : [" << Min << "nm --> " << Max << "nm]" << endl;
			}
			cout << "====================" << endl;
            cout << endl << "Select Grating::";
			cin >> iChoice;
			specrographError=ATSpectrographSetGrating(0, iChoice);
			if(specrographError!=ATSPECTROGRAPH_SUCCESS) cout << "Invalid grating!" << endl;

		}
			break;
		case 'd': //Set wavelength
			{
			float wave, Min, Max;
			int igrat(0);
			ATSpectrographGetGrating(0, &igrat);
			ATSpectrographGetWavelength(0,&wave);
			cout << "\nCurrent wavelength : " << wave << "nm" << endl;
			ATSpectrographGetWavelengthLimits(0, igrat, &Min, &Max);
			printf("Enter new wavelength[%fnm-->%fnm]::", Min, Max);
			}
			cin >> fChoice;

			specrographError=ATSpectrographSetWavelength(0, fChoice);
			if(specrographError!=ATSPECTROGRAPH_SUCCESS) cout << "Invalid wavelength!" << endl;

			break;

		case 'e':
		{
			float *  waves = new float[width];
			specrographError = ATSpectrographGetCalibration(0, waves, width);
			if (specrographError != ATSPECTROGRAPH_SUCCESS) {
				cout << "Failed to get calibration data err=" << specrographError << endl;
			}
				for (int i = 0; i < 5; i++) cout << "pixel " << i << " wavelength=" << waves[i] << endl;
				for (int i = width - 5; i < width; i++) cout << "pixel " << i << " wavelength=" << waves[i] << endl;
			delete[] waves;
		}
			break;
		case 'z': //Exit

			quit = true;

			break;

		default:

			cout << "!Invalid Option!" << endl;

		}
		getchar();

	}while(!quit);

	ATSpectrographClose();
	//Shut down CCD
	ShutDown();

	return 0;
}

void DisplaySpectrographStatus()
{
	int gratingNo;
	float lines;
	char blaze[256] = { 0 };
	int home;
	int offset;

	ATSpectrographGetGrating(0, &gratingNo);
	ATSpectrographGetGratingInfo(0, gratingNo, &lines, blaze, 255, &home, &offset);

	float wavelength;
	ATSpectrographGetWavelength(0, &wavelength);


	cout << "Grating: Lines="<< lines << endl;
	cout << "Wavelength =" << wavelength << endl;
    cout << "====================" << endl;
}

int CameraSelect (int iNumArgs, char* szArgList[])
{
  if (iNumArgs == 2) {

    at_32 lNumCameras;
    GetAvailableCameras(&lNumCameras);
    int iSelectedCamera = atoi(szArgList[1]);

    if (iSelectedCamera < lNumCameras && iSelectedCamera >= 0) {
      at_32 lCameraHandle;
      GetCameraHandle(iSelectedCamera, &lCameraHandle);
      SetCurrentCamera(lCameraHandle);
      return iSelectedCamera;
    }
    else
      return -1;
  }
  return 0;
}
