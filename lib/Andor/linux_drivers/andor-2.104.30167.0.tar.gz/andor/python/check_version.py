import sys

if not sys.version_info.major == 3:

    print("Python 3 is required.")

    print("Python {} detected.".format(sys.version_info.major))

    sys.exit(1)